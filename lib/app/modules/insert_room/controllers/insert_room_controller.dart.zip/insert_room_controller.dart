import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:basir_core_sdk/basir_core_sdk.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:grpc/grpc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:proximity_screen_lock/proximity_screen_lock.dart';
import 'package:screen_recorder_device/app/core/connectivity/socket_connection.dart';
import 'package:basir_core_sdk/src/modules/auth/models/phone_history.dart';
import 'package:screen_recorder_device/app/core/connectivity/socket_listener.dart';
import 'package:screen_recorder_device/app/modules/insert_room/views/calling_view.dart';
import 'package:screen_recorder_device/app/modules/insert_room/views/calling_voice_view.dart';
import 'package:screen_recorder_device/app/modules/insert_room/views/incoming_view.dart';
import 'package:screen_recorder_device/app/modules/insert_room/views/incoming_voice_view.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart' as WRTC;
import 'package:screen_recorder_device/app/modules/insert_room/views/outgoing_video_view.dart';
import 'package:screen_recorder_device/app/modules/insert_room/views/outgoing_view.dart';
import 'package:screen_recorder_device/app/routes/app_pages.dart';
import 'package:stop_watch_timer/stop_watch_timer.dart';

class InsertRoomController extends GetxController
    with GetSingleTickerProviderStateMixin {
  RxString roomId = ''.obs;
  RxString roomId1 = ''.obs;
  RxList rooms = [].obs;
  RxBool loading = false.obs;
  RxBool applyRoomId = false.obs;
  List<String> arguments = [''];
  TextEditingController roomFormFieldController = TextEditingController();
  TextEditingController whiteListNumber = TextEditingController();
  TextEditingController whiteListFrom = TextEditingController();
  TextEditingController whiteListto = TextEditingController();
  TextEditingController whiteListLevel = TextEditingController();
  final TextEditingController myController = TextEditingController();

  RxString phoneNumber = ''.obs;
  late final focusNode = FocusNode();

  final dropDownValue = Rx<dynamic>(null);
  final onSelected = Rx<dynamic>(null);

  RxDouble xx = 0.0.obs;
  RxDouble yy = 0.0.obs;

  RxList<dynamic> phoneList = [].obs;

  RxList<dynamic> lst = [].obs;
  final ScrollController scrollController = ScrollController();
  RxInt dialNumber = 0.obs;
  RxString outgoingNumber = ''.obs;
  RxString callerID = 'false'.obs;

  RxInt totalNumbers = 0.obs;
  RxList numbers = [].obs;
  Map<String, dynamic> tokens = {};

  WRTC.RTCVideoRenderer localRenderer = WRTC.RTCVideoRenderer();
  RxList remoteRenderers = [].obs;
  RxBool initialize = false.obs;
  RxBool grid = false.obs;
  ReceivePort? _receivePort;
  RxInt grideNum = 1.obs;
  final remoteRenderer = Rx<dynamic>(null);
  late WRTC.MediaStream localStream;

  RxString type = ''.obs;
  RxBool hide = false.obs;
  RxString peerNum = ''.obs;
  // RxList<PhoneNumbersHistory> recentNumbers = RxList<PhoneNumbersHistory>([]);
  RxList<String> recentNumbers = [''].obs;

  RxInt from = 0.obs;
  RxInt to = 9.obs;

  RxBool requestVideoCall = false.obs;
  RxBool remoteRenderersInitialized = false.obs;
  RxBool socketDestroyed = false.obs;

  RxBool endedCall = false.obs;

  RxString stat = ''.obs;

  late WRTC.RTCPeerConnection _peerConnection;

  late AnimationController controller;

  late Tween<double> rotationTween;
  late Tween<double> positionTween;
  final Curve curve = Curves.elasticOut;

  late Animation<double> rotationAnimation;
  late Animation<double> scaleAnimation1;
  late Animation<double> scaleAnimation2;
  late Animation<double> scaleAnimation3;
  late Animation<double> scaleAnimation4;
  late Animation<double> scaleAnimation5;
  late Animation<double> positionAnimation1;
  late Animation<double> positionAnimation2;
  late Animation<double> positionAnimation3;
  late Animation<double> positionAnimation4;
  late Animation<double> positionAnimation5;

  late TweenSequence<Alignment> tweenSequenceAlignment;
  late TweenSequence<double> tweenSequencePosition;
  late TweenSequence<double> tweenSequencePosition1;

  void onSelection() {
    if (focusNode.hasFocus) {
      myController.selection = TextSelection.fromPosition(
        TextPosition(
          offset: myController.text.length,
        ),
      );
    }
  }

  @override
  void onInit() {
    // focusNode.addListener(onSelection);

    myController.addListener(() {
      print(myController.text);
      phoneNumber.value = myController.text;
      myController.selection =
          // TextSelection.collapsed(offset: myController.text.length);te

          // TextSelection.fromPosition(
          //     TextPosition(offset: myController.text.length));

          myController.selection = TextSelection(
        baseOffset: myController.text.length,
        extentOffset: myController.text.length,
      );
    });
    super.onInit();
    controller =
        AnimationController(duration: const Duration(seconds: 6), vsync: this);

    tweenSequencePosition1 = TweenSequence<double>(
      [
        TweenSequenceItem(tween: Tween(begin: 350, end: 0), weight: 4),
        TweenSequenceItem(tween: Tween(begin: 0, end: 50), weight: 4),

        TweenSequenceItem(tween: Tween(begin: 50, end: 0), weight: 3),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 15), weight: 3),

        // TweenSequenceItem(tween: Tween(begin: 15, end: 0), weight: 3),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 5), weight: 3),

        // TweenSequenceItem(tween: Tween(begin: 5, end: 0), weight: 3),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 20), weight: 2),

        // TweenSequenceItem(tween: Tween(begin: 20, end: 0), weight: 1),

        // TweenSequenceItem(tween: Tween(begin: 0, end: 60), weight: 20),
        // TweenSequenceItem(tween: Tween(begin: 60, end: 0), weight: 15),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 50), weight: 20),
        // TweenSequenceItem(tween: Tween(begin: 50, end: 0), weight: 15),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 40), weight: 20),
        // TweenSequenceItem(tween: Tween(begin: 40, end: 0), weight: 15),
        // TweenSequenceItem(tween: Tween(begin: 0, end: 30), weight: 20),
        // TweenSequenceItem(tween: Tween(begin: 30, end: 0), weight: 15)
      ],
    );

    tweenSequencePosition = TweenSequence<double>(
      [
        TweenSequenceItem(tween: Tween(begin: 0, end: 1), weight: 1),
        TweenSequenceItem(tween: Tween(begin: 1, end: 0.7), weight: 2),
        TweenSequenceItem(tween: Tween(begin: 0.7, end: 0.8), weight: 2),
        TweenSequenceItem(tween: Tween(begin: 0.6, end: 1), weight: 1),
      ],
    );

    tweenSequencePosition.chain(CurveTween(curve: curve));

    // positionTween = Tween(begin: 250, end: 10);
    // positionTween.chain(CurveTween(curve: curve));
    // positionAnimation = controller.drive(tweenSequencePosition);

    scaleAnimation1 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.1,
        0.2,
      ),
    ).drive(tweenSequencePosition);
    scaleAnimation2 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.3,
        0.4,
      ),
    ).drive(tweenSequencePosition);
    scaleAnimation3 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.6,
        0.7,
      ),
    ).drive(tweenSequencePosition);
    scaleAnimation4 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.9,
        1,
      ),
    ).drive(tweenSequencePosition);
    scaleAnimation5 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0,
        0.1,
      ),
    ).drive(tweenSequencePosition);

    tweenSequencePosition1.chain(CurveTween(curve: curve));

    // positionTween = Tween(begin: 250, end: 10);
    // positionTween.chain(CurveTween(curve: curve));
    // positionAnimation = controller.drive(tweenSequencePosition);
    positionAnimation1 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0,
        0.1,
      ),
    ).drive(tweenSequencePosition1);
    positionAnimation2 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.3,
        0.4,
      ),
    ).drive(tweenSequencePosition1);
    positionAnimation3 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.5,
        0.6,
      ),
    ).drive(tweenSequencePosition1);
    positionAnimation4 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.7,
        0.8,
      ),
    ).drive(tweenSequencePosition1);
    positionAnimation5 = CurvedAnimation(
      parent: controller,
      curve: Interval(
        0.8,
        0.9,
      ),
    ).drive(tweenSequencePosition1);

    rotationTween = Tween(begin: 0, end: 8 * pi);
    rotationTween.chain(CurveTween(curve: curve));
    rotationAnimation = controller.drive(rotationTween);

    onceAfterInitialized();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() async {
    super.onClose();
    myController.dispose();
    focusNode.dispose();
    // _stopForegroundTask();
    // _closeReceivePort();
    await stopWatchTimer.dispose();
    exit(0);
  }

  Future<void> onRefresh() async {
    // monitor network fetch
    await Future.delayed(const Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
  }

  Future<List> fetchDataList() async {
    Timer(const Duration(seconds: 1), (() {
      lst.addAll([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
    }));
    return lst;
  }

  Future<void> addRecentNumbers() async {
    List<String> newList = [];
    var getHistory = await BasirCore().storage.getPhoneNumbers();

    if (getHistory == null) {
      var current = PhoneNumbersHistory(
          ownNumber: dropDownValue.value.toString(),
          numbers: [outgoingNumber.value],
          time: '1000');
      await BasirCore().storage.storePhoneNumbers(phoneNumbers: current);
    } else {
      newList = getHistory.numbers!;
      newList.add(outgoingNumber.value);
      var finalList = newList.toSet().toList();

      var newObj = PhoneNumbersHistory(
          ownNumber: dropDownValue.value.toString(),
          numbers: finalList,
          time: '1000');
      await BasirCore().storage.storePhoneNumbers(phoneNumbers: newObj);
    }
  }

  Future<PhoneNumbersHistory?> getRecentNumbers() async {
    return await BasirCore().storage.getPhoneNumbers();
  }

  getRoomId(String text) {
    roomId.value = text;
  }

  void requestCall() async {
    // endedCall.value = false;
    // FlutterRingtonePlayer.playRingtone(looping: true);
    if (socketDestroyed.value) {
      Get.defaultDialog(content: Text('Socket Closed Later!'));
    } else {
      type.value == 'video'
          ? requestVideoCall.value = true
          : requestVideoCall.value = false;

      BasirCore().callSocket.sink.add(makeCallData());
    }
  }

  Future<void> requestCancelCall() async {
    await AwesomeNotifications().dismissAllNotifications();

    BasirCore().callSocket.sink.add(makeCancelCallData());

    requestVideoCall.value = false;

    // BasirCore().callSocket.sink.add(makeEndCallData());
    // BasirCore().callSocket.sink.add(makeEndPeerConnectionData());
    await webRTCdispose();
    StopTimer();
    goToInsertRoomPage();
  }

  void callerConnect() {
    BasirCore().callSocket.sink.add(makeCallerData());
  }

  Future<void> answerVideoCall() async {
    // endedCall.value = false;
    // print('RAWWWWWWW: ${arguments[3]}');
    BasirCore().callSocket.sink.add(makeAnswerCallData(arguments[3]));
    // FlutterRingtonePlayer.stop();

    goToVideoCallingPage();
  }

  Future<void> answerVoiceCall() async {
    // endedCall.value = false;
    print('RAWWWWWWW: ${arguments[3]}');
    BasirCore().callSocket.sink.add(makeAnswerCallData(arguments[3]));
    // await FlutterRingtonePlayer.stop();

    goToVoiceCallingPage();
  }

  Future<void> endCall() async {
    // if (endedCall.value == false) {
    await AwesomeNotifications().dismissAllNotifications();

    turnFlash.value = true;
    turnOffCam.value = true;
    speakerPhone.value = true;
    muted.value = true;
    cameraDirection.value = false;
    requestVideoCall.value = false;

    BasirCore().callSocket.sink.add(makeEndCallData());
    BasirCore().callSocket.sink.add(makeEndPeerConnectionData());
    await webRTCdispose();

    try {
      await ProximityScreenLock.setActive(false);
    } catch (e) {
      debugPrint('Something went wrong: $e');
    }

    StopTimer();
    goToInsertRoomPage();
    endedCall.value = true;
    // onceAfterInitialized();
    // }
  }

  void goToOutgoingView() {
    // Get.to(() => CallingView());
    Get.to(() => OutgoingView());
  }

  void goToOutgoingVideoView() {
    // Get.to(() => CallingView());
    Get.to(() => OutgoingVideoView());
  }

  void goToIncomingViewPage() {
    // Get.to(() => CallingView());
    Get.to(() => IncomingVoiceView());
  }

  void goToVideoCallingPage() {
    // StartTimer();
    Get.to(() => CallingView());
    // controller.forward();
  }

  void goToVoiceCallingPage() async {
    // StartTimer();

    try {
      await ProximityScreenLock.setActive(true);
    } catch (e) {
      debugPrint('Something went wrong: $e');
    }

    Get.to(() => CallingVoiceView());
  }

  void goToInsertRoomPage() {
    Get.offAndToNamed(Routes.INSERT_ROOM);
  }

  String makeSocketSignInData() {
    var socketSignInData = {
      "own_number": numbers[0].number,
      "token": tokens['accessToken'],
      "agent": 'mobile_device'
    };
    var socketData = JsonEncoder()
        .convert({"event": 'user_signin', "data": socketSignInData});
    print('Socket Data: $socketData');
    return socketData;
  }

  String makeAnswerCallData(String room) {
    var socketSignInData = {
      "room_id": room,
    };
    var socketData = JsonEncoder()
        .convert({"event": "answer_call", "data": socketSignInData});
    // print('Socket Data: $socketData');
    return socketData;
  }

  String makeEndCallData() {
    var socketData =
        JsonEncoder().convert({"event": "end_call_requesting", "data": null});
    // print('Socket Data: $socketData');
    return socketData;
  }

  String makeEndPeerConnectionData() {
    var socketData =
        JsonEncoder().convert({"event": "on_return_webrtc", "data": null});
    // print('Socket Data: $socketData');
    return socketData;
  }

  String makeCallData() {
    var data = {
      "peer_number": outgoingNumber.value,
      "type": type.value,
      "hide": callerID.value == 'false' ? false : true
    };
    var socketData = JsonEncoder().convert({"event": "call_to", "data": data});
    print('Socket Data: $socketData');
    return socketData;
  }

  String makeCancelCallData() {
    var data = {
      "room_id": arguments[3],
    };
    var socketData =
        JsonEncoder().convert({"event": "cancel_call", "data": data});
    print('Socket Data: $socketData');
    return socketData;
  }

  String makeCallerData() {
    var data = {
      "room_id": arguments[3],
    };
    var socketData =
        JsonEncoder().convert({"event": "on_webrtc_caller", "data": data});
    print('Socket Data: $socketData');
    return socketData;
  }

  final StopWatchTimer stopWatchTimer = StopWatchTimer(
    mode: StopWatchMode.countUp,
    onChange: (value) {},
    onChangeRawSecond: (value) {},
    onChangeRawMinute: (value) {},
    onStopped: () {
      print('onStop');
    },
    onEnded: () {
      print('onEnded');
    },
  );

  void StartTimer() {
    stopWatchTimer.rawTime.listen((value) {});
    // _stopWatchTimer.minuteTime.listen((value) {});
    // _stopWatchTimer.secondTime.listen((value) {});
    // _stopWatchTimer.records.listen((value) {});
    // _stopWatchTimer.fetchStopped.listen((value) {});
    // _stopWatchTimer.fetchEnded.listen((value) {});

    stopWatchTimer.onStartTimer();
  }

  void StopTimer() {
    stopWatchTimer.onResetTimer();
    stopWatchTimer.onStopTimer();
  }

  onceAfterInitialized() async {
    // var room = await BasirCore().storage.getRoom();
    // if (room != null) {
    //   roomId.value = room;
    //   roomFormFieldController.text = room;
    // }

    // _initForegroundTask();
    // await _startForegroundTask();

    // Timer(Duration(seconds: 5), (() {
    //   FlutterForegroundTask.wakeUpScreen();
    // }));

    await Permission.camera.request();
    await Permission.audio.request();
    await Permission.microphone.request();
    await Permission.storage.request();
    await Permission.accessMediaLocation.request();
    await Permission.mediaLibrary.request();
    await Permission.manageExternalStorage.request();
    await Permission.videos.request();
    await Permission.criticalAlerts.request();
    await Permission.ignoreBatteryOptimizations.request();
    await Permission.notification.request();
    await Permission.scheduleExactAlarm.request();
    await Permission.systemAlertWindow.request();

    await initNotification();

    var fetchedRecent = await getRecentNumbers();

    if (fetchedRecent != null && fetchedRecent.numbers != null) {
      recentNumbers.removeAt(0);
      fetchedRecent.numbers?.forEach((element) {
        recentNumbers.add(element);
      });
    }

    tokens = await BasirCore().storage.getTokens();
    if (await getNumbers()) {
      if (await connect()) {
      } else {
        Get.defaultDialog(title: 'خطا', content: const Text('اتصال اینترنت'));
        Future.delayed(const Duration(seconds: 2))
            .then((value) => Get.offAndToNamed(Routes.HOME));
        // Get.back();
      }
    } else {
      Get.defaultDialog(title: 'خطا', content: const Text('اتصال اینترنت'));
      Future.delayed(const Duration(seconds: 2))
          .then((value) => Get.offAndToNamed(Routes.HOME));
      // Get.back();
    }
  }

  Future<bool> addWhiteListLevel(String ownNumber, int level) async {
    try {
      await BasirCore().call.addWhiteListLevel(ownNumber, level);
      Get.defaultDialog(title: 'Message', content: const Text('Level Added'));
      return true;
    } on GrpcError catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    } catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    }
  }

  Future<bool> addWhiteListRange(String ownNumber, int from, int to) async {
    try {
      await BasirCore().call.addWhiteListRange(ownNumber, from, to);
      Get.defaultDialog(title: 'Message', content: const Text('Range Added'));
      return true;
    } on GrpcError catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    } catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    }
  }

  Future<bool> addWhiteListNum(String ownNumber, String peerNumber) async {
    try {
      await BasirCore().call.addWhiteListNumber(ownNumber, peerNumber);
      Get.defaultDialog(title: 'Message', content: const Text('Number Added'));
      return true;
    } on GrpcError catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    } catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    }
  }

  Future<bool> getWhiteList() async {
    try {
      var whiteLists =
          await BasirCore().call.getWhitelists(dropDownValue.value.toString());
      // print(whiteLists);
      Get.defaultDialog(
          title: 'شماره های مجاز', content: Text('${whiteLists.whitelist}'));
      return true;
    } on GrpcError catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    } catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    }
  }

  Future<bool> getNumbers() async {
    try {
      var getNumbers = await BasirCore().call.getNumbers();
      numbers.value = getNumbers.numbers;
      totalNumbers.value = getNumbers.total;

      getNumbers.numbers.forEach((element) {
        phoneList.add(element.number.toString());
      });

      // Get.defaultDialog(title: 'Numbers', content: Text('${numbers}'));

      return true;
    } on GrpcError catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    } catch (e) {
      Get.defaultDialog(title: 'خطا', content: Text('$e'));
      return false;
    }
  }

  RxBool cameraDirection = false.obs;
  Future<void> switchCamera() async {
    localStream.getVideoTracks()[0].setTorch(false);
    if (cameraDirection.value) {
      cameraDirection.value = false;
      await WRTC.Helper.switchCamera(localStream.getVideoTracks()[0]);
    } else {
      cameraDirection.value = true;
      await WRTC.Helper.switchCamera(localStream.getVideoTracks()[0]);
    }
  }

  RxBool muted = true.obs;
  Future<void> muteMicrophone() async {
    if (muted.value) {
      muted.value = false;
      WRTC.Helper.setMicrophoneMute(true, localStream.getAudioTracks()[0]);
    } else {
      muted.value = true;
      WRTC.Helper.setMicrophoneMute(false, localStream.getAudioTracks()[0]);
    }
  }

  RxBool speakerPhone = true.obs;
  Future<void> muteSpeaker() async {
    if (speakerPhone.value) {
      speakerPhone.value = false;
      await WRTC.Helper.setSpeakerphoneOn(false);
    } else {
      speakerPhone.value = true;
      await WRTC.Helper.setSpeakerphoneOn(true);
    }
  }

  RxBool turnOffCam = true.obs;
  Future<void> turnOffCamera() async {
    localStream.getVideoTracks()[0].setTorch(false);
    if (turnOffCam.value) {
      turnOffCam.value = false;
      localStream.getVideoTracks()[0].enabled =
          !localStream.getVideoTracks()[0].enabled;
    } else {
      turnOffCam.value = true;
      localStream.getVideoTracks()[0].enabled =
          !localStream.getVideoTracks()[0].enabled;
    }
  }

  RxBool turnFlash = true.obs;
  Future<void> turnOffFlash() async {
    if (turnFlash.value) {
      turnFlash.value = false;
      localStream.getVideoTracks()[0].setTorch(false);
    } else {
      turnFlash.value = true;
      localStream.getVideoTracks()[0].setTorch(true);
    }
  }

  Future<void> webRTCdispose() async {
    if (initialize.value) {
      await closeCameraStream();

      if (localRenderer.srcObject != null) {
        localRenderer.srcObject = null;
        // await localRenderer.dispose();
      }

      if (remoteRenderersInitialized.value) {
        // remoteRenderers[0] = null;
        remoteRenderers.clear();
        // remoteRenderer.close();
        remoteRenderersInitialized.value = false;
      }

      await sender.dispose();

      await _peerConnection.close();
      await _peerConnection.dispose();

      initialize.value = false;
    }

    // await AwesomeNotifications().removeChannel('basic_channel_group');

    // await BasirCore().callSocket.dispose();
  }

  Future<void> closeCameraStream() async {
    if (localStream.getVideoTracks().isNotEmpty) {
      localStream.getVideoTracks()[0].setTorch(false);
      // await localStream.getVideoTracks()[0].stop();
    } else {}

    // localStream.getTracks().forEach((element) async {
    //   await element.stop();
    // });
    // await localStream.dispose();
  }

  late WRTC.RTCRtpSender sender;

  Future<void> webRTCinit() async {
    _peerConnection = await WRTC.createPeerConnection({}, {});

    await localRenderer.initialize();
    localStream = await WRTC.navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': type.value == 'video'
          ? {'facingMode': "user", 'width': 320, 'height': 240}
          : false,
    });
    // localStream = await WRTC.navigator.mediaDevices
    //     .getDisplayMedia({'audio': true, 'video': true});
    // setState(() {
    localRenderer.srcObject = localStream;
    // });
    initialize.value = true;

    localStream.getTracks().forEach((track) async {
      sender = await _peerConnection.addTrack(track, localStream);
    });

    _peerConnection.onAddTrack = (stream, track) {};

    _peerConnection.onConnectionState = (state) {
      stat.value = 'PeerConnection: $state';
      // Get.snackbar(
      //   backgroundColor: Colors.white38,
      //   animationDuration: Duration(seconds: 1),
      //   'Message',
      //   stat.value,
      // );
    };
    _peerConnection.onSignalingState = (state) {
      stat.value = 'Signaling: $state';
      // Get.snackbar(
      //   backgroundColor: Colors.white38,
      //   animationDuration: Duration(seconds: 1),
      //   'Message',
      //   stat.value,
      // );
    };

    _peerConnection.onRemoveTrack = (stream, track) async {
      // if (endedCall.value == false) {
      await endCall();
      // }
    };

    _peerConnection.onIceCandidate = (candidate) {
      // Get.snackbar(
      //   backgroundColor: Colors.white38,
      //   animationDuration: Duration(seconds: 1),
      //   'Message',
      //   'Candidate: $candidate',
      // );
      // print("LOGGGG CANDIDATE ICE IN");
      if (candidate == null) {
        return;
      }

      // print("LOGGGG CANDIDATE ICE VALID");

      var candidateJson = JsonEncoder().convert({
        'sdpMLineIndex': candidate.sdpMLineIndex,
        'sdpMid': candidate.sdpMid,
        'candidate': candidate.candidate,
      });

      // print("LOGGGG CANDIDATE ICE CONTENT: $candidateJson");

      var candidateWS =
          JsonEncoder().convert({"event": "candidate", "data": candidateJson});

      // _socket.add(candidateWS);
      BasirCore().callSocket.sink.add(candidateWS);
    };

    _peerConnection.onTrack = (event) async {
      // print('LOGGGG TRACK RECEIVED ${event.track.kind}');
      if (event.track.kind == 'video' && event.streams.isNotEmpty) {
        var renderer = WRTC.RTCVideoRenderer();
        await renderer.initialize();

        renderer.srcObject = event.streams[0];

        // setState(() {
        remoteRenderers.add(renderer);
        remoteRenderersInitialized.value = true;
        // });
      }
    };

    _peerConnection.onRemoveStream = (stream) {
      var rendererToRemove;
      var newRenderList = [];

      // Filter existing renderers for the stream that has been stopped
      remoteRenderers.forEach((r) {
        if (r.srcObject.id == stream.id) {
          rendererToRemove = r;
        } else {
          newRenderList.add(r);
        }
      });

      // Set the new renderer list
      // setState(() {
      remoteRenderers.value = newRenderList;
      // });

      // Dispose the renderer we are done with
      if (rendererToRemove != null) {
        rendererToRemove.dispose();
      }
    };
  }

  Future<bool> connect() async {
    await BasirCore().callSocket.initialize();

    if (BasirCore().callSocket.initialized) {
      socketDestroyed.value = false;
      BasirCore().callSocket.sink.add(makeSocketSignInData());
      BasirCore().callSocket.stream.listen(
        (raw) async {
          try {
            Map<String, dynamic> msg = await jsonDecode(raw);
            // print('RAWWWWWWW: $raw');
            if (msg['error'] != null) {
              // Get.defaultDialog(content: Text('Error: ${msg['error']}'));
              Get.snackbar(
                isDismissible: true,
                backgroundColor: Colors.white60,
                animationDuration: Duration(seconds: 1),
                dismissDirection: DismissDirection.horizontal,
                'Message',
                'Error: ${msg['error']}',
              );
              return;
            }

            switch (msg["event"]) {
              case "on_waiting":
                initialize.value ? null : await webRTCinit();

                // BasirCore().callSocket
                //     .channel!
                //     .sink
                //     .add(makeAnswerCallData(msg["room_id"]));
                arguments.clear();
                arguments.add(msg["type"]);
                arguments.add(msg["hide"].toString());
                arguments.add(msg["peer_number"]);
                arguments.add(msg["room_id"]);
                // goToOutgoingView();
                // print('ROOOOOOM: ${arguments}');

                // await FlutterRingtonePlayer.playRingtone(looping: true);
                // FlutterForegroundTask.launchApp();
                await AwesomeNotifications().createNotification(
                  content: NotificationContent(
                      notificationLayout: NotificationLayout.Default,
                      autoDismissible: true,

                      // customSound: 'asset://assets/mix.wav',
                      category: NotificationCategory.Call,
                      displayOnForeground: true,
                      displayOnBackground: true,
                      criticalAlert: true,
                      wakeUpScreen: true,
                      fullScreenIntent: true,
                      id: arguments[0] == "video" ? 10 : 20,
                      channelKey: 'basic_channel',
                      title: 'تماس ورودی',
                      body: 'شماره: ${msg["peer_number"]}',
                      actionType: ActionType.SilentAction),
                );

                return;

              case 'on_calling':
                initialize.value ? null : await webRTCinit();
                // print('RAWWWWWWW: on_callingggggggggggggg');
                arguments.clear();
                arguments.add(msg["type"]);
                arguments.add(msg["hide"].toString());
                arguments.add(msg["peer_number"]);
                arguments.add(msg["room_id"]);
                requestVideoCall.value
                    ? goToOutgoingVideoView()
                    : goToOutgoingView();
                return;

              case 'webrtc_connection':
                // print('RAWWWWWWW: webrtc_connection');
                initialize.value ? null : await webRTCinit();
                callerConnect();
                requestVideoCall.value
                    ? goToVideoCallingPage()
                    : goToVoiceCallingPage();
                await AwesomeNotifications().dismissAllNotifications();
                return;

              case 'ended_call':
                // BasirCore().callSocket.sink.add(makeEndPeerConnectionData());
                // print('RAWWWWWWW: ended_call');
                // Get.snackbar(
                //   backgroundColor: Colors.white38,
                //   animationDuration: Duration(seconds: 1),
                //   dismissDirection: DismissDirection.horizontal,
                //   'Message',
                //   'ended_call',
                // );
                // Get.defaultDialog(content: Text('ended_call'));
                // await Future.delayed(Duration(seconds: 3))
                //     .then((value) async => await endCall());
                await endCall();
                // await AwesomeNotifications().dismissAllNotifications();

                return;

              case 'rejected_call':
                print('RAWWWWWWW: rejected_call');
                // Get.snackbar(
                //     backgroundColor: Colors.white38,
                //     animationDuration: Duration(seconds: 1),
                //     dismissDirection: DismissDirection.horizontal,
                //     'Message',
                //     'rejected_call');
                // Get.defaultDialog(content: Text('rejected_call'));
                // await Future.delayed(Duration(seconds: 3))
                //     .then((value) async => await endCall());
                await endCall();
                // await AwesomeNotifications().dismissAllNotifications();
                return;

              case 'reject_call':
                // Get.snackbar(
                //     backgroundColor: Colors.white38,
                //     animationDuration: Duration(seconds: 1),
                //     dismissDirection: DismissDirection.horizontal,
                //     'Message',
                //     'reject_call');
                print('RAWWWWWWW: reject_call');
                // Get.defaultDialog(content: Text('reject_call'));
                // await Future.delayed(Duration(seconds: 3))
                //     .then((value) async => await endCall());
                await endCall();
                // await AwesomeNotifications().dismissAllNotifications();
                return;

              case 'canceled_call':
                print('Canelllllllll');
                // Get.snackbar(
                //     backgroundColor: Colors.white38,
                //     animationDuration: Duration(seconds: 1),
                //     dismissDirection: DismissDirection.horizontal,
                //     'Message',
                //     'canceled_call');
                // print('RAWWWWWWW: canceled_call');
                // Get.defaultDialog(content: Text('canceled_call'));
                // await Future.delayed(Duration(seconds: 3))
                //     .then((value) async => await endCall());
                await endCall();
                // await AwesomeNotifications().dismissAllNotifications();
                return;

              case 'call_failed':
                // Get.snackbar(
                //     backgroundColor: Colors.white38,
                //     animationDuration: Duration(seconds: 1),
                //     dismissDirection: DismissDirection.horizontal,
                //     'Message',
                //     'call_failed');
                // print('RAWWWWWWW: call_failed');
                // Get.defaultDialog(content: Text('call_failed'));
                // await Future.delayed(Duration(seconds: 3))
                //     .then((value) async => await endCall());
                await endCall();
                // await AwesomeNotifications().dismissAllNotifications();

                return;

              case 'candidate':
                initialize.value ? null : await webRTCinit();
                // print('LOGGGG CANDIDATE WS RECEIVED');
                Map<String, dynamic> parsed = jsonDecode(msg['data']);
                var c = parsed['candidate'];
                // print('LOGGGG CANDIDATE WS CONTENT: $c');

                try {
                  await _peerConnection
                      .addCandidate(
                          WRTC.RTCIceCandidate(parsed['candidate'], '', 0))
                      .catchError((err) {
                    // print('LOGGGG CANDIDATE WS $err');
                  });
                  // print('LOGGGG CANDIDATE WS ADDED');
                } catch (err) {
                  // print('LOGGGG CANDIDATE WS $err');
                }
                return;
              case 'offer':
                initialize.value ? null : await webRTCinit();
                // print('LOGGGG 2.1');
                // await Future.delayed(Duration(seconds: 25));
                // print('LOGGGG 2.2');
                Map<String, dynamic> offer = jsonDecode(msg['data']);

                // SetRemoteDescription and create answer
                await _peerConnection.setRemoteDescription(
                    WRTC.RTCSessionDescription(offer['sdp'], offer['type']));
                WRTC.RTCSessionDescription answer =
                    await _peerConnection.createAnswer({});
                // print('LOGGGG  ${answer.sdp}');
                await _peerConnection.setLocalDescription(answer);

                // Send answer over WebSocket
                // _socket.add(JsonEncoder().convert({
                BasirCore().callSocket.sink.add(JsonEncoder().convert({
                      'event': 'answer',
                      'data': JsonEncoder()
                          .convert({'type': answer.type, 'sdp': answer.sdp})
                    }));
                // print('LOGGGG 2.3');
                return;
            }
          } catch (e) {
            // Get.snackbar(
            //     backgroundColor: Colors.white38,
            //     animationDuration: Duration(seconds: 1),
            //     dismissDirection: DismissDirection.horizontal,
            //     'Message',
            //     'Data Error $e');
            // await endCall();
            // Get.defaultDialog(content: Text('Data Error $e'));
            // await Future.delayed(Duration(seconds: 3))
            //     .then((value) async => await endCall());

            // socketSignInError.value = true;
          }
        },
        onDone: () async {
          if (!BasirCore().callSocket.initialized) {
            await BasirCore().callSocket.initialize();
            // Get.snackbar(
            //     backgroundColor: Colors.white38,
            //     animationDuration: Duration(seconds: 1),
            //     dismissDirection: DismissDirection.horizontal,
            //     'Message',
            //     'Closed by server!');
            // await endCall();
            // socketDestroyed.value = true;
            // Get.defaultDialog(content: Text('Closed by server!'));
            // await Future.delayed(Duration(seconds: 3))
            //     .then((value) async => await endCall());
          }
        },
        onError: (e) async {
          // Get.snackbar(
          //     backgroundColor: Colors.white38,
          //     animationDuration: Duration(seconds: 1),
          //     dismissDirection: DismissDirection.horizontal,
          //     'Message',
          //     'Data Error $e');
          // await endCall();

          // Get.defaultDialog(content: Text('Socket Error $e'));
          // await Future.delayed(Duration(seconds: 3))
          //     .then((value) async => await endCall());
        },
      );
      return true;
    } else {
      return false;
    }
  }

  // Future<bool> connect() async {
  //   // SocketListener socketListener = SocketListener();
  //   if (SocketListener().connected) {
  //     SocketListener().events.listen(
  //       (msg) async {
  //         try {
  //           // print('RAWWWWWWW: $raw');
  //           if (msg['error'] != null) {
  //             // Get.defaultDialog(content: Text('Error: ${msg['error']}'));
  //             Get.snackbar(
  //               isDismissible: true,
  //               backgroundColor: Colors.white60,
  //               animationDuration: Duration(seconds: 1),
  //               dismissDirection: DismissDirection.horizontal,
  //               'Message',
  //               'Error: ${msg['error']}',
  //             );
  //             return;
  //           }

  //           switch (msg["event"]) {
  //             case "on_waiting":
  //               initialize.value ? null : await webRTCinit();

  //               // BasirCore().callSocket
  //               //     .channel!
  //               //     .sink
  //               //     .add(makeAnswerCallData(msg["room_id"]));
  //               arguments.clear();
  //               arguments.add(msg["type"]);
  //               arguments.add(msg["hide"].toString());
  //               arguments.add(msg["peer_number"]);
  //               arguments.add(msg["room_id"]);
  //               // goToOutgoingView();
  //               // print('ROOOOOOM: ${arguments}');

  //               // await FlutterRingtonePlayer.playRingtone(looping: true);
  //               // FlutterForegroundTask.launchApp();
  //               await AwesomeNotifications().createNotification(
  //                 content: NotificationContent(
  //                     notificationLayout: NotificationLayout.Default,
  //                     autoDismissible: true,

  //                     // customSound: 'asset://assets/mix.wav',
  //                     category: NotificationCategory.Call,
  //                     displayOnForeground: true,
  //                     displayOnBackground: true,
  //                     criticalAlert: true,
  //                     wakeUpScreen: true,
  //                     fullScreenIntent: true,
  //                     id: arguments[0] == "video" ? 10 : 20,
  //                     channelKey: 'basic_channel',
  //                     title: 'تماس ورودی',
  //                     body: 'شماره: ${msg["peer_number"]}',
  //                     actionType: ActionType.SilentAction),
  //               );

  //               return;

  //             case 'on_calling':
  //               initialize.value ? null : await webRTCinit();
  //               // print('RAWWWWWWW: on_callingggggggggggggg');
  //               arguments.clear();
  //               arguments.add(msg["type"]);
  //               arguments.add(msg["hide"].toString());
  //               arguments.add(msg["peer_number"]);
  //               arguments.add(msg["room_id"]);
  //               requestVideoCall.value
  //                   ? goToOutgoingVideoView()
  //                   : goToOutgoingView();
  //               return;

  //             case 'webrtc_connection':
  //               // print('RAWWWWWWW: webrtc_connection');
  //               initialize.value ? null : await webRTCinit();
  //               callerConnect();
  //               requestVideoCall.value
  //                   ? goToVideoCallingPage()
  //                   : goToVoiceCallingPage();
  //               await AwesomeNotifications().dismissAllNotifications();
  //               return;

  //             case 'ended_call':
  //               // BasirCore().callSocket.sink.add(makeEndPeerConnectionData());
  //               // print('RAWWWWWWW: ended_call');
  //               // Get.snackbar(
  //               //   backgroundColor: Colors.white38,
  //               //   animationDuration: Duration(seconds: 1),
  //               //   dismissDirection: DismissDirection.horizontal,
  //               //   'Message',
  //               //   'ended_call',
  //               // );
  //               // Get.defaultDialog(content: Text('ended_call'));
  //               // await Future.delayed(Duration(seconds: 3))
  //               //     .then((value) async => await endCall());
  //               await endCall();
  //               // await AwesomeNotifications().dismissAllNotifications();

  //               return;

  //             case 'rejected_call':
  //               print('RAWWWWWWW: rejected_call');
  //               // Get.snackbar(
  //               //     backgroundColor: Colors.white38,
  //               //     animationDuration: Duration(seconds: 1),
  //               //     dismissDirection: DismissDirection.horizontal,
  //               //     'Message',
  //               //     'rejected_call');
  //               // Get.defaultDialog(content: Text('rejected_call'));
  //               // await Future.delayed(Duration(seconds: 3))
  //               //     .then((value) async => await endCall());
  //               await endCall();
  //               // await AwesomeNotifications().dismissAllNotifications();
  //               return;

  //             case 'reject_call':
  //               // Get.snackbar(
  //               //     backgroundColor: Colors.white38,
  //               //     animationDuration: Duration(seconds: 1),
  //               //     dismissDirection: DismissDirection.horizontal,
  //               //     'Message',
  //               //     'reject_call');
  //               print('RAWWWWWWW: reject_call');
  //               // Get.defaultDialog(content: Text('reject_call'));
  //               // await Future.delayed(Duration(seconds: 3))
  //               //     .then((value) async => await endCall());
  //               await endCall();
  //               // await AwesomeNotifications().dismissAllNotifications();
  //               return;

  //             case 'canceled_call':
  //               print('Canelllllllll');
  //               // Get.snackbar(
  //               //     backgroundColor: Colors.white38,
  //               //     animationDuration: Duration(seconds: 1),
  //               //     dismissDirection: DismissDirection.horizontal,
  //               //     'Message',
  //               //     'canceled_call');
  //               // print('RAWWWWWWW: canceled_call');
  //               // Get.defaultDialog(content: Text('canceled_call'));
  //               // await Future.delayed(Duration(seconds: 3))
  //               //     .then((value) async => await endCall());
  //               await endCall();
  //               // await AwesomeNotifications().dismissAllNotifications();
  //               return;

  //             case 'call_failed':
  //               // Get.snackbar(
  //               //     backgroundColor: Colors.white38,
  //               //     animationDuration: Duration(seconds: 1),
  //               //     dismissDirection: DismissDirection.horizontal,
  //               //     'Message',
  //               //     'call_failed');
  //               // print('RAWWWWWWW: call_failed');
  //               // Get.defaultDialog(content: Text('call_failed'));
  //               // await Future.delayed(Duration(seconds: 3))
  //               //     .then((value) async => await endCall());
  //               await endCall();
  //               // await AwesomeNotifications().dismissAllNotifications();

  //               return;

  //             case 'candidate':
  //               initialize.value ? null : await webRTCinit();
  //               // print('LOGGGG CANDIDATE WS RECEIVED');
  //               Map<String, dynamic> parsed = jsonDecode(msg['data']);
  //               var c = parsed['candidate'];
  //               // print('LOGGGG CANDIDATE WS CONTENT: $c');

  //               try {
  //                 await _peerConnection
  //                     .addCandidate(
  //                         WRTC.RTCIceCandidate(parsed['candidate'], '', 0))
  //                     .catchError((err) {
  //                   // print('LOGGGG CANDIDATE WS $err');
  //                 });
  //                 // print('LOGGGG CANDIDATE WS ADDED');
  //               } catch (err) {
  //                 // print('LOGGGG CANDIDATE WS $err');
  //               }
  //               return;
  //             case 'offer':
  //               initialize.value ? null : await webRTCinit();
  //               // print('LOGGGG 2.1');
  //               // await Future.delayed(Duration(seconds: 25));
  //               // print('LOGGGG 2.2');
  //               Map<String, dynamic> offer = jsonDecode(msg['data']);

  //               // SetRemoteDescription and create answer
  //               await _peerConnection.setRemoteDescription(
  //                   WRTC.RTCSessionDescription(offer['sdp'], offer['type']));
  //               WRTC.RTCSessionDescription answer =
  //                   await _peerConnection.createAnswer({});
  //               // print('LOGGGG  ${answer.sdp}');
  //               await _peerConnection.setLocalDescription(answer);

  //               // Send answer over WebSocket
  //               // _socket.add(JsonEncoder().convert({
  //               BasirCore().callSocket.sink.add(JsonEncoder().convert({
  //                     'event': 'answer',
  //                     'data': JsonEncoder()
  //                         .convert({'type': answer.type, 'sdp': answer.sdp})
  //                   }));
  //               // print('LOGGGG 2.3');
  //               return;
  //           }
  //         } catch (e) {
  //           // Get.snackbar(
  //           //     backgroundColor: Colors.white38,
  //           //     animationDuration: Duration(seconds: 1),
  //           //     dismissDirection: DismissDirection.horizontal,
  //           //     'Message',
  //           //     'Data Error $e');
  //           // await endCall();
  //           // Get.defaultDialog(content: Text('Data Error $e'));
  //           // await Future.delayed(Duration(seconds: 3))
  //           //     .then((value) async => await endCall());

  //           // socketSignInError.value = true;
  //         }
  //       },
  //       onDone: () async {
  //         if (!BasirCore().callSocket.initialized) {
  //           await BasirCore().callSocket.initialize();
  //           // Get.snackbar(
  //           //     backgroundColor: Colors.white38,
  //           //     animationDuration: Duration(seconds: 1),
  //           //     dismissDirection: DismissDirection.horizontal,
  //           //     'Message',
  //           //     'Closed by server!');
  //           // await endCall();
  //           // socketDestroyed.value = true;
  //           // Get.defaultDialog(content: Text('Closed by server!'));
  //           // await Future.delayed(Duration(seconds: 3))
  //           //     .then((value) async => await endCall());
  //         }
  //       },
  //       onError: (e) async {
  //         // Get.snackbar(
  //         //     backgroundColor: Colors.white38,
  //         //     animationDuration: Duration(seconds: 1),
  //         //     dismissDirection: DismissDirection.horizontal,
  //         //     'Message',
  //         //     'Data Error $e');
  //         // await endCall();

  //         // Get.defaultDialog(content: Text('Socket Error $e'));
  //         // await Future.delayed(Duration(seconds: 3))
  //         //     .then((value) async => await endCall());
  //       },
  //     );
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  Future<void> initNotification() async {
    await Permission.notification.request();
    await Permission.accessNotificationPolicy.request();

    await AwesomeNotifications().initialize(
        // set the icon to null if you want to use the default app icon
        // 'resource://drawable/res_app_icon',
        null,
        [
          NotificationChannel(
              importance: NotificationImportance.High,
              ledOnMs: 1000,
              ledOffMs: 500,
              // soundSource: 'resource://raw/mix.wav',
              playSound: false,
              defaultRingtoneType: DefaultRingtoneType.Ringtone,
              enableLights: true,
              enableVibration: false,
              defaultPrivacy: NotificationPrivacy.Public,
              channelGroupKey: 'basic_channel_group',
              channelKey: 'basic_channel',
              channelName: 'Basic notifications',
              channelDescription: 'Notification channel for basic tests',
              defaultColor: Color(0xFF9D50DD),
              ledColor: Colors.white)
        ],
        // Channel groups are only visual and are not required
        channelGroups: [
          NotificationChannelGroup(
              channelGroupKey: 'basic_channel_group',
              channelGroupName: 'Basic group')
        ],
        debug: true);
    await AwesomeNotifications().requestPermissionToSendNotifications();
    ReceivedAction? initialAction = await AwesomeNotifications()
        .getInitialNotificationAction(removeFromActionEvents: false);

    await AwesomeNotifications().setListeners(
        onActionReceivedMethod: NotificationController.onActionReceivedMethod,
        onNotificationCreatedMethod:
            NotificationController.onNotificationCreatedMethod,
        onNotificationDisplayedMethod:
            NotificationController.onNotificationDisplayedMethod,
        onDismissActionReceivedMethod:
            NotificationController.onDismissActionReceivedMethod);
    await AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
        // This is just a basic example. For real apps, you must show some
        // friendly dialog box before call the request method.
        // This is very important to not harm the user experience
        AwesomeNotifications().requestPermissionToSendNotifications();
      }
    });
  }

  // // The callback function should always be a top-level function.
  // @pragma('vm:entry-point')
  // void startCallback() {
  //   // The setTaskHandler function must be called to handle the task in the background.
  //   FlutterForegroundTask.setTaskHandler(MyTaskHandler());
  // }

  // void _initForegroundTask() {
  //   FlutterForegroundTask.init(
  //     androidNotificationOptions: AndroidNotificationOptions(
  //       channelId: 'notification_channel_id',
  //       channelName: 'Foreground Notification',
  //       channelDescription:
  //           'This notification appears when the foreground service is running.',
  //       channelImportance: NotificationChannelImportance.LOW,
  //       priority: NotificationPriority.LOW,
  //       iconData: null,
  //       //  const NotificationIconData(
  //       //   resType: ResourceType.mipmap,
  //       //   resPrefix: ResourcePrefix.ic,
  //       //   name: 'launcher',
  //       //   backgroundColor: Colors.red,
  //       // ),
  //       buttons: [
  //         // const NotificationButton(id: 'sendButton', text: 'Send'),
  //         // const NotificationButton(id: 'testButton', text: 'Test'),
  //       ],
  //     ),
  //     iosNotificationOptions: const IOSNotificationOptions(
  //       showNotification: true,
  //       playSound: false,
  //     ),
  //     foregroundTaskOptions: const ForegroundTaskOptions(
  //       interval: 5000,
  //       isOnceEvent: false,
  //       autoRunOnBoot: true,
  //       allowWakeLock: true,
  //       allowWifiLock: true,
  //     ),
  //   );
  // }

  // Future<bool> _startForegroundTask() async {
  //   // You can save data using the saveData function.
  //   await FlutterForegroundTask.saveData(key: 'customData', value: 'hello');

  //   // Register the receivePort before starting the service.
  //   final ReceivePort? receivePort = FlutterForegroundTask.receivePort;
  //   final bool isRegistered = _registerReceivePort(receivePort);
  //   if (!isRegistered) {
  //     print('Failed to register receivePort!');
  //     return false;
  //   }

  //   if (await FlutterForegroundTask.isRunningService) {
  //     return FlutterForegroundTask.restartService();
  //   } else {
  //     return FlutterForegroundTask.startService(
  //       notificationTitle: 'سرویس تماس بصیر فعال است',
  //       notificationText: 'جهت بازگشت به برنامه ضربه بزنید',
  //       callback: startCallback,
  //     );
  //   }
  // }

  // Future<bool> _stopForegroundTask() {
  //   return FlutterForegroundTask.stopService();
  // }

  // bool _registerReceivePort(ReceivePort? newReceivePort) {
  //   if (newReceivePort == null) {
  //     return false;
  //   }

  //   _closeReceivePort();

  //   _receivePort = newReceivePort;
  //   _receivePort?.listen((message) {
  //     if (message is int) {
  //       print('eventCount: $message');
  //     } else if (message is String) {
  //       if (message == 'onNotificationPressed') {
  //         // Navigator.of(context).pushNamed('/resume-route');
  //       }
  //     } else if (message is DateTime) {
  //       print('timestamp: ${message.toString()}');
  //     }
  //   });

  //   return _receivePort != null;
  // }

  // void _closeReceivePort() {
  //   _receivePort?.close();
  //   _receivePort = null;
  // }

  // T? _ambiguate<T>(T? value) => value;
}

// class MyTaskHandler extends TaskHandler {
//   SendPort? _sendPort;
//   int _eventCount = 0;

//   @override
//   Future<void> onStart(DateTime timestamp, SendPort? sendPort) async {
//     _sendPort = sendPort;

//     // You can use the getData function to get the stored data.
//     final customData =
//         await FlutterForegroundTask.getData<String>(key: 'customData');
//     print('customData: $customData');
//   }

//   @override
//   Future<void> onEvent(DateTime timestamp, SendPort? sendPort) async {
//     FlutterForegroundTask.updateService(
//       notificationTitle: 'MyTaskHandler',
//       notificationText: 'eventCount: $_eventCount',
//     );

//     // Send data to the main isolate.
//     sendPort?.send(_eventCount);

//     _eventCount++;
//   }

//   @override
//   Future<void> onDestroy(DateTime timestamp, SendPort? sendPort) async {
//     // You can use the clearAllData function to clear all the stored data.
//     await FlutterForegroundTask.clearAllData();
//   }

//   @override
//   void onButtonPressed(String id) {
//     // Called when the notification button on the Android platform is pressed.
//     print('onButtonPressed >> $id');
//   }

//   @override
//   void onNotificationPressed() {
//     // Called when the notification itself on the Android platform is pressed.
//     //
//     // "android.permission.SYSTEM_ALERT_WINDOW" permission must be granted for
//     // this function to be called.

//     // Note that the app will only route to "/resume-route" when it is exited so
//     // it will usually be necessary to send a message through the send port to
//     // signal it to restore state when the app is already started.
//     FlutterForegroundTask.launchApp("/resume-route");
//     _sendPort?.send('onNotificationPressed');
//   }
// }

class NotificationController {
  /// Use this method to detect when a new notification or a schedule is created
  @pragma("vm:entry-point")
  static Future<void> onNotificationCreatedMethod(
      ReceivedNotification receivedNotification) async {
    // Your code goes here
  }

  /// Use this method to detect every time that a new notification is displayed
  @pragma("vm:entry-point")
  static Future<void> onNotificationDisplayedMethod(
      ReceivedNotification receivedNotification) async {
    switch (receivedNotification.id) {
      case 10:
        Get.to(IncomingView());
        return;
      case 20:
        Get.to(IncomingVoiceView());
        return;

      default:
        break;
    }

    // Get.to(NotifView());
    // print('onNotificationDisplayedMethod');
    // Your code goes here
  }

  /// Use this method to detect if the user dismissed a notification
  @pragma("vm:entry-point")
  static Future<void> onDismissActionReceivedMethod(
      ReceivedAction receivedAction) async {
    // Your code goes here
  }

  /// Use this method to detect when the user taps on a notification or action button
  @pragma("vm:entry-point")
  static Future<void> onActionReceivedMethod(
      ReceivedAction receivedAction) async {
    // Your code goes here

    // Navigate into pages, avoiding to open the notification details page over another details page already opened
    // MyApp.navigatorKey.currentState?.pushNamedAndRemoveUntil('/notification-page',
    //         (route) => (route.settings.name != '/notification-page') || route.isFirst,
    //     arguments: receivedAction);
  }
}
