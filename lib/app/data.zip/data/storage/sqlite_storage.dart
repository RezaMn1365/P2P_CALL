import 'storage_driver.dart';

class SqliteStorage extends StorageDriver {
  @override
  Future<String?> getString(String key) {
    // TODO: implement getString
    throw UnimplementedError();
  }

  @override
  Future<double?> getDouble(String key) {
    // TODO: implement getString
    throw UnimplementedError();
  }

  @override
  Future<void> init() {
    // TODO: implement init
    throw UnimplementedError();
  }

  @override
  Future<void> putString(String key, String value) {
    // TODO: implement putString
    throw UnimplementedError();
  }

  @override
  Future<void> putDouble(String key, double value) {
    // TODO: implement putString
    throw UnimplementedError();
  }

  @override
  Future<void> clear() {
    // TODO: implement clear
    throw UnimplementedError();
  }
}
